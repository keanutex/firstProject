import unittest
import demo

class TestPCA (unittest.TestCase):


     def test_readFile1 (self):
         result = demo.PCAPlotter.readFile1(self,'comm.phe')
         self.assertIsNotNone (result)

     def test_readFile2 (self):
        result = demo.PCAPlotter.readFile2(self,'comm-SYMCL.pca.evec')
        self.assertEqual(result, 3)


if __name__ == '__main__':
    unittest.main()


