import unittest
import Admix

class TestAdmix (unittest.TestCase):


    def test_readFile1 (self):
         result = Admix.admixPlotter.readFile1(self,'small.fam')
         self.assertEqual(result, 6)


    def test_readFile2 (self):
        result = Admix.admixPlotter.readFile2(self,'small.Q.2')
        self.assertEqual(result, 4)

    def test_readFile3 (self):
        result = Admix.admixPlotter.readFile3(self,'small.phe',4)
        self.assertEqual(result, 6)

if __name__ == '__main__':
    unittest.main()
